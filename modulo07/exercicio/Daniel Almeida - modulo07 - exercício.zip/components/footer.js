class Footer extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `<footer>
      <p>
        Desenvolvido por
        <a href="https://github.com/DexDevLab" target="_blank"
          >Daniel Almeida</a
        >
      </p>
    </footer>`;
  }
}

customElements.define("component-footer", Footer);
