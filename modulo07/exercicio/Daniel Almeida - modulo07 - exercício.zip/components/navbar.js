class Navbar extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `<nav>
        <h3><a href="./homepage.html">Home</a></h3>
        <h3>Aulas</h3>
        <ul>
          <li>
            <a href="./01-introducao.html">Introdução</a>
          </li>
          <li>
            <a href="./02-listas-e-links.html"
              >Listas e Links</a
            >
          </li>
          <li>
            <a href="./03-formatacao-de-texto.html"
              >Formatação de Texto</a
            >
          </li>
          <li><a href="./04-tabelas.html">Tabelas</a></li>
          <li>
            <a href="./05-layouts.html">Layouts</a>
          </li>
          <li>
            <a href="./06-formularios.html"
              >Formulários</a
            >
          </li>
          <li>
            <a href="./07-modulo07.html"
              >Módulo 07</a
            >
          </li>
        </ul>
        <h3>Redes Sociais</h3>
        <ul>
          <li>
            <a
              href="https://www.linkedin.com/in/daniel-augusto-almeida/"
              target="_blank"
              >LinkedIn</a
            >
          </li>
          <li>
            <a href="https://www.instagram.com/ei_dex/" target="_blank"
              >Instagram</a
            >
          </li>
        </ul>
      </nav>`;
  }
}

customElements.define("component-navbar", Navbar);
